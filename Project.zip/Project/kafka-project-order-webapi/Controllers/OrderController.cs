﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

// TODO: Add namespaces
using kafka_project_order_webapi.Models;
using kafka_project_order_webapi.Helpers;
using Confluent.Kafka;
using Newtonsoft.Json;

namespace kafka_project_order_webapi.Controllers
{
    [ApiController]
    [Route("/api/order")]
    public class OrderController : ControllerBase
    {
        private ProducerConfig _config;

        public OrderController(ProducerConfig config)
        {
            _config = config;
        }

        [HttpGet]
        public IEnumerable<Order02> GetOrders()
        {
            // TODO: Modify this code to use Entity Framework and the scaffolded/auto-generated model class for the Order table

            // var sampleOrders = new List<OrderModel> {
            //     new OrderModel { OrderId = "5a59bab5-5e2e-46d6-a6ef-97cb446ec9f9", CustomerName = "Bob Smith", OrderDescription = "Mobile Phone", OrderDate = new DateTime(2022, 01, 02, 10, 10, 00), OrderAmount = 699.95F, OrderStatus = "PENDING"},
            //     new OrderModel { OrderId = "5a59bab5-5e2e-46d6-a6ef-97cb446ec9f8", CustomerName = "Drew Smith", OrderDescription = "PS5", OrderDate = new DateTime(2022, 02, 03, 05, 06, 00), OrderAmount = 299.95F, OrderStatus = "PLACED"},
            //     new OrderModel { OrderId = "5a59bab5-5e2e-46d6-a6ef-97cb446ec9f7", CustomerName = "Bob Smith", OrderDescription = "Laptop", OrderDate = new DateTime(2022, 03, 04, 09, 11, 00), OrderAmount = 1699.95F, OrderStatus = "SHIPPED"}
            // };

            // return sampleOrders;
            var context = new KafkaLabContext();
            return context.Order02s;
        }

        [HttpGet("{id}")]
        public Order02 GetOrderById(string id)
        {
            // TODO: Modify this code to use Entity Framework and the scaffolded/auto-generated model class for the Order table

            // var sampleOrders = new List<OrderModel> {
            //     new OrderModel { OrderId = "5a59bab5-5e2e-46d6-a6ef-97cb446ec9f9", CustomerName = "Bob Smith", OrderDescription = "Mobile Phone", OrderDate = new DateTime(2022, 01, 02, 10, 10, 00), OrderAmount = 699.95F, OrderStatus = "PENDING"},
            //     new OrderModel { OrderId = "5a59bab5-5e2e-46d6-a6ef-97cb446ec9f8", CustomerName = "Drew Smith", OrderDescription = "PS5", OrderDate = new DateTime(2022, 02, 03, 05, 06, 00), OrderAmount = 299.95F, OrderStatus = "PLACED"},
            //     new OrderModel { OrderId = "5a59bab5-5e2e-46d6-a6ef-97cb446ec9f7", CustomerName = "Bob Smith", OrderDescription = "Laptop", OrderDate = new DateTime(2022, 03, 04, 09, 11, 00), OrderAmount = 1699.95F, OrderStatus = "SHIPPED"}
            // };

            // var order = sampleOrders.Where( order => order.OrderId == id).SingleOrDefault();

            // return order;

            var context = new KafkaLabContext();
            var order = context.Order02s.Where(order => order.OrderId == new Guid(id)).SingleOrDefault();

            return order!;
        }

        [HttpPost]
        public async Task<string> PostOrder(Order02 model)
        {
            // TODO: Modify this code to add Kafka support.
            // NOTE: This DELETE method in the starter project is there as placeholder. It works but since we have in-memory data, the data isn't really deleted.

            // var sampleOrders = new List<OrderModel> {
            //     new OrderModel { OrderId = "5a59bab5-5e2e-46d6-a6ef-97cb446ec9f9", CustomerName = "Bob Smith", OrderDescription = "Mobile Phone", OrderDate = new DateTime(2022, 01, 02, 10, 10, 00), OrderAmount = 699.95F, OrderStatus = "PENDING"},
            //     new OrderModel { OrderId = "5a59bab5-5e2e-46d6-a6ef-97cb446ec9f8", CustomerName = "Drew Smith", OrderDescription = "PS5", OrderDate = new DateTime(2022, 02, 03, 05, 06, 00), OrderAmount = 299.95F, OrderStatus = "PLACED"},
            //     new OrderModel { OrderId = "5a59bab5-5e2e-46d6-a6ef-97cb446ec9f7", CustomerName = "Bob Smith", OrderDescription = "Laptop", OrderDate = new DateTime(2022, 03, 04, 09, 11, 00), OrderAmount = 1699.95F, OrderStatus = "SHIPPED"}
            // };

            // model.OrderId = Guid.NewGuid().ToString();
            // sampleOrders.Add(model);

            // return $"The {model.OrderId} order has been placed";

            model.OrderId = Guid.NewGuid();
            model.OrderDate = DateTime.Now;

            var jsonMessage = JsonConvert.SerializeObject(model);
            var producerHelper = new ProducerHelper(_config, "orders");
            await producerHelper.SendMessage(model.OrderId.ToString(), jsonMessage);

            return $"OrderId: {model.OrderId} received!";
        }

        [HttpDelete("{id}")]
        public async Task<string> DeleteOrderById(string id)
        {
            // TODO: Modify this code to add Kafka support.
            // NOTE: This DELETE method in the starter project is there as placeholder. It works but since we have in-memory data, the data isn't really deleted.

            // var sampleOrders = new List<OrderModel> {
            //     new OrderModel { OrderId = "5a59bab5-5e2e-46d6-a6ef-97cb446ec9f9", CustomerName = "Bob Smith", OrderDescription = "Mobile Phone", OrderDate = new DateTime(2022, 01, 02, 10, 10, 00), OrderAmount = 699.95F, OrderStatus = "PENDING"},
            //     new OrderModel { OrderId = "5a59bab5-5e2e-46d6-a6ef-97cb446ec9f8", CustomerName = "Drew Smith", OrderDescription = "PS5", OrderDate = new DateTime(2022, 02, 03, 05, 06, 00), OrderAmount = 299.95F, OrderStatus = "PLACED"},
            //     new OrderModel { OrderId = "5a59bab5-5e2e-46d6-a6ef-97cb446ec9f7", CustomerName = "Bob Smith", OrderDescription = "Laptop", OrderDate = new DateTime(2022, 03, 04, 09, 11, 00), OrderAmount = 1699.95F, OrderStatus = "SHIPPED"}
            // };

            // var result = sampleOrders.Remove(sampleOrders.Where(order => order.OrderId == id).SingleOrDefault());

            // return result;

            var context = new KafkaLabContext();
            var record = context.Order02s.Where(o => o.OrderId.ToString() == id).SingleOrDefault();
            var message = string.Empty;

            if (record != null)
            {
                Console.WriteLine($"Delete request for {record.OrderId}");
                if (record.OrderStatus.Equals("SHIPPED"))
                {
                    message = $"OrderId: {record.OrderId} has been SHIPPED and cannot be deleted!";
                }
                else if (record.OrderStatus.Equals("PLACED") || record.OrderStatus.Equals("PENDING"))
                {
                    record.OrderStatus = "DELETE";
                    var jsonMessage = JsonConvert.SerializeObject(record);
                    var producerHelper = new ProducerHelper(_config, "orders");
                    await producerHelper.SendMessage(record.OrderId.ToString(), jsonMessage);
                    message = $"OrderId: {record.OrderId} deleted!";
                }
            }
            return message;
        }
    }
}
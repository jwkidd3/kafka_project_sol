﻿using System;
using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using kafka_project_mvc.Models;
using kafka_project_mvc.Helpers;
using System.Threading.Tasks;
using Newtonsoft.Json;
using System.Collections.Generic;

// TODO: namespaces

namespace kafka_project_mvc.Controllers
{
  public class HomeController : Controller
  {
    private readonly ILogger<HomeController> _logger;
    private OrderHelper _orderHelper;

    public HomeController(ILogger<HomeController> logger)
    {
      _logger = logger;
      _orderHelper = new OrderHelper();
    }

    public IActionResult Index()
    {
      return View();
    }

    [HttpGet, ActionName("Orders")]
    public ActionResult ViewOrders()
    {
      ViewBag.Message = TempData["message"];

      Console.WriteLine("---Getting data from OrderAPI (i.e. Azure SQL Database)---");
      var response = _orderHelper.GetOrders().Result;
      Console.WriteLine("----------------------------");
      Console.WriteLine(response);
      var deserializedOrders = JsonConvert.DeserializeObject<List<OrderModel>>(response);
      
      return View(deserializedOrders);
    }

    [HttpGet, ActionName("Order")]
    public IActionResult PlaceOrder()
    {

      return View();
    }

    [HttpPost, ActionName("Order")]
    public IActionResult PlaceOrder(OrderModel model)
    {
      Console.Write("PlaceOrder Hit");
      
      var response = _orderHelper.PlaceOrder(model).Result;
      ViewBag.Message = response;
      return View();
    }

    [HttpGet, ActionName("Delete")]
    public async Task<IActionResult> DeleteOrder(string id)
    {

      var response = _orderHelper.DeleteOrder(id).Result;
      await _orderHelper.DeleteOrder(id);
      Console.WriteLine(response);

      TempData["message"] = response;
      return RedirectToAction("Orders");
    }

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
      return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
  }
}

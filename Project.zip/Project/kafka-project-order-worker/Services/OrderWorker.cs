using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
// TODO: add namespaces
using Confluent.Kafka;
using Newtonsoft.Json;
using kafka_project_order_worker.Helpers;
using kafka_project_order_worker.Models;

namespace kafka_project_order_worker.Services
{
    public class OrderWorker : BackgroundService
    {
        // TODO: appsettings dependency injection
        ProducerConfig _producerConfig;
        ConsumerConfig _consumerConfig;

        public OrderWorker(ProducerConfig producerConfig, ConsumerConfig consumerConfig)
        {
            _producerConfig = producerConfig;
            _consumerConfig = consumerConfig;
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            Console.WriteLine($"Order worker started...");

            var consumerHelper = new ConsumerHelper(_consumerConfig, "orders");

            while (!stoppingToken.IsCancellationRequested)
            {
                string message = consumerHelper.ReadMessage();
                Console.WriteLine(message);

                // TODO: add database code here
                var order = JsonConvert.DeserializeObject<Order02>(message);
                var jsonMessage = JsonConvert.SerializeObject(order);
                using (KafkaLabContext context = new KafkaLabContext())
                {
                    if (order!.OrderStatus.Equals("PENDING"))
                    {
                        try
                        {
                            order.OrderStatus = "PLACED";
                            context.Order02s.Add(order);
                            context.SaveChanges();
                            var producerHelper = new ProducerHelper(_producerConfig, "shipping");
                            await producerHelper.SendMessage(order.OrderId.ToString(), jsonMessage);

                            Console.WriteLine($"---Info: Order placed: {jsonMessage}---");

                        }
                        catch (System.Exception exc)
                        {
                            Console.WriteLine(exc);
                        }
                    }
                    else if (order.OrderStatus.Equals("DELETE"))
                    {
                        var record = context.Order02s.Where(o => o.OrderId == order.OrderId).SingleOrDefault();
                        if (record != null)
                        {
                            context.Order02s.Remove(record);
                            context.SaveChanges();

                            Console.WriteLine($"---Info: Order deleted: {jsonMessage}---");
                        }
                    }
                }
            }
        }
    }
}

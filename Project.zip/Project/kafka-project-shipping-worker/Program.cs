using Confluent.Kafka;
using kafka_project_shipping_worker.Services;


var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var consumerConfig = new ConsumerConfig();
builder.Configuration.Bind("ConsumerConfig", consumerConfig);
builder.Services.AddSingleton<ConsumerConfig>(consumerConfig);
builder.Services.AddSingleton<IHostedService, ShippingWorker>();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();
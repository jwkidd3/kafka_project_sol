﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace kafka_project_shipping_worker.Models
{
    public partial class KafkaLabContext : DbContext
    {
        public KafkaLabContext()
        {
        }

        public KafkaLabContext(DbContextOptions<KafkaLabContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Order02> Order02s { get; set; } = null!;

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
                optionsBuilder.UseSqlServer("Server=tcp:azuresql-server-707209.database.windows.net,1433;Initial Catalog=KafkaLab;Persist Security Info=False;User ID=dba;Password=Passw0rD-707209;MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;Connection Timeout=30;");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Order02>(entity =>
            {
                entity.HasKey(e => e.OrderId)
                    .HasName("PK__Order02__C3905BCF3F02301B");

                entity.ToTable("Order02");

                entity.Property(e => e.OrderId).ValueGeneratedNever();

                entity.Property(e => e.CustomerName)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.OrderAmount).HasColumnType("decimal(18, 0)");

                entity.Property(e => e.OrderDate).HasColumnType("datetime");

                entity.Property(e => e.OrderDescription)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.OrderStatus)
                    .HasMaxLength(10)
                    .IsUnicode(false);
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}

﻿using System;
using System.Collections.Generic;

namespace kafka_project_shipping_worker.Models
{
    public partial class Order02
    {
        public Guid OrderId { get; set; }
        public string CustomerName { get; set; } = null!;
        public string OrderDescription { get; set; } = null!;
        public DateTime OrderDate { get; set; }
        public decimal OrderAmount { get; set; }
        public string OrderStatus { get; set; } = null!;
    }
}

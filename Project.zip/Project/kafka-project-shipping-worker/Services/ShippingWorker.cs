using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
// TODO: add namespaces
using Confluent.Kafka;
using Newtonsoft.Json;
using kafka_project_shipping_worker.Helpers;
using kafka_project_shipping_worker.Models;

namespace kafka_project_shipping_worker.Services
{
    public class ShippingWorker : BackgroundService
    {
        // TODO: appsettings dependency injection
        ConsumerConfig _consumerConfig;

        public ShippingWorker(ConsumerConfig consumerConfig)
        {
            _consumerConfig = consumerConfig;  
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            Console.WriteLine($"Shipping worker started...");

            var consumerHelper = new ConsumerHelper(_consumerConfig, "shipping");
            
            while (!stoppingToken.IsCancellationRequested)
            {
                // TODO: worker logic
                
                string message = consumerHelper.ReadMessage();
                Console.WriteLine($"preparing order {message}");
            
                // TODO: add database code here
                using(KafkaLabContext context = new KafkaLabContext())
                {
                  var order = JsonConvert.DeserializeObject<Order02>(message);
                  var existingOrder = context.Order02s.Where(o => o.OrderId == order!.OrderId).SingleOrDefault();
                  if(existingOrder != null)
                  {
                    existingOrder.OrderStatus = "SHIPPED";
                    context.SaveChanges();    
                  }
                  Console.WriteLine($"---Info: Order shipped: {message}---");
                }
            }
        }
    }
}
